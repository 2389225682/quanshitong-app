# 全史通 - 中国历史深度学习网站 Android APP

> 从零开始，读懂中国千年

全史通是一款全景式中国历史学习APP，覆盖秦朝至民国14个朝代，每个朝代包含8大主题共168页内容。

## 功能特点

- **14个朝代完整覆盖**：秦、汉、三国、晋、南北朝、隋、唐、五代十国、宋、元、明、清、民国
- **8大主题**：国家机构、军政制度、税收政策、法律制度、百姓生活、社会阶级、对外关系、物价参考
- **168页丰富内容**：每主题5000-10000字，通俗易懂，生动有趣
- **完全离线**：无需网络，所有内容内置于APP中
- **国潮古风设计**：每朝代独立配色，视觉体验沉浸

## 项目结构

```
app/src/main/
├── assets/          # 网站HTML/CSS内容（168页）
├── java/            # Android源码
│   └── com/quanshitong/app/
│       └── MainActivity.java  # WebView主活动
├── res/             # Android资源
│   ├── values/      # 字符串、样式
│   └── mipmap-*/    # APP图标
└── AndroidManifest.xml
```

## 编译APK

### 方式一：GitHub Actions（推荐，免费）

1. 将此项目推送到GitHub仓库
2. 进入仓库 → Actions 标签
3. 点击 "Build Android APK" → "Run workflow"
4. 等待编译完成（约3-5分钟）
5. 在 Artifacts 中下载 `quanshitong-release.apk`
6. 传到手机安装即可

### 方式二：本地编译

1. 安装 [Android Studio](https://developer.android.com/studio)
2. 打开此项目目录
3. Build → Build Bundle(s) / APK(s) → Build APK(s)
4. APK位于 `app/build/outputs/apk/release/`

## 技术栈

- Android WebView（内置浏览器）
- 纯HTML/CSS静态页面
- 最低支持 Android 5.0（API 21）
- 目标 Android 14（API 34）

## 安装说明

1. 下载APK文件
2. 手机设置 → 允许安装未知来源应用
3. 打开APK文件安装
4. 桌面出现"全史通"图标，点击即可使用

## 截图预览

APP打开后展示14个朝代的入口卡片，点击任一朝代进入该朝代的详细学习页面。支持朝代切换、阅读进度追踪、返回导航等功能。
