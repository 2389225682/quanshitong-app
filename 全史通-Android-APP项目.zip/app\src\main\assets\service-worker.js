const CACHE_NAME = 'quantong-v1';

const PRECACHE_URLS = [
    './',
    './index.html',
    './styles.css',
    './manifest.json',
];

// 朝代列表
const DYNASTIES = ['qin','han','sanguo','jin','nanbeichao','sui','tang','wudai','song','yuan','ming','qing','minguo'];
const PAGES = ['index.html','institution.html','military.html','tax.html','law.html','life.html','class.html','foreign.html','price.html','events.html','figures.html','diary.html'];

DYNASTIES.forEach(d => {
    PAGES.forEach(p => {
        PRECACHE_URLS.push(`./${d}/${p}`);
    });
    PRECACHE_URLS.push(`./${d}/styles.css`);
});

// 安装：预缓存所有资源
self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME).then(cache => {
            console.log('预缓存', PRECACHE_URLS.length, '个资源');
            return cache.addAll(PRECACHE_URLS);
        }).then(() => self.skipWaiting())
    );
});

// 激活：清理旧缓存
self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(keys => 
            Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
        ).then(() => self.clients.claim())
    );
});

// 拦截请求：缓存优先
self.addEventListener('fetch', event => {
    event.respondWith(
        caches.match(event.request).then(cached => {
            return cached || fetch(event.request).then(response => {
                if (response.ok) {
                    const clone = response.clone();
                    caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
                }
                return response;
            });
        }).catch(() => {
            if (event.request.mode === 'navigate') {
                return caches.match('./index.html');
            }
        })
    );
});
